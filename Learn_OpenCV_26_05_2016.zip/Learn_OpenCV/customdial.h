#ifndef CUSTOMDIAL_H
#define CUSTOMDIAL_H

#include <QDial>



class CustomDial : public QDial
{
public:
  CustomDial();
};

#endif // CUSTOMDIAL_H
